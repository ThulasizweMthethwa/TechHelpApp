import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(), // 'student', 'hr', 'hiring_manager'
  studentNumber: text("student_number"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const jobs = pgTable("jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  department: text("department").notNull(),
  positionType: text("position_type").notNull(),
  description: text("description").notNull(),
  requirements: text("requirements").array().notNull(),
  location: text("location"),
  hoursPerWeek: integer("hours_per_week"),
  deadline: timestamp("deadline").notNull(),
  postedBy: varchar("posted_by").notNull().references(() => users.id),
  postedDate: timestamp("posted_date").defaultNow().notNull(),
  status: text("status").notNull().default("open"), // 'open', 'closed'
});

export const applications = pgTable("applications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  jobId: varchar("job_id").notNull().references(() => jobs.id),
  studentId: varchar("student_id").notNull().references(() => users.id),
  status: text("status").notNull().default("submitted"), // 'submitted', 'under_review', 'shortlisted', 'interview_scheduled', 'hired', 'rejected'
  resumeUrl: text("resume_url"),
  aiScore: real("ai_score"),
  appliedDate: timestamp("applied_date").defaultNow().notNull(),
  interviewDate: timestamp("interview_date"),
  interviewTime: text("interview_time"),
});

export const academicRecords = pgTable("academic_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id").notNull().references(() => users.id),
  courseCode: text("course_code").notNull(),
  courseName: text("course_name").notNull(),
  grade: text("grade").notNull(),
  credits: integer("credits").notNull(),
  semester: text("semester").notNull(),
  year: integer("year").notNull(),
});

export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // 'info', 'success', 'warning'
  read: text("read").notNull().default("false"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertJobSchema = createInsertSchema(jobs).omit({
  id: true,
  postedDate: true,
  status: true,
});

export const insertApplicationSchema = createInsertSchema(applications).omit({
  id: true,
  appliedDate: true,
  status: true,
  aiScore: true,
});

export const insertAcademicRecordSchema = createInsertSchema(academicRecords).omit({
  id: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
  read: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertJob = z.infer<typeof insertJobSchema>;
export type Job = typeof jobs.$inferSelect;

export type InsertApplication = z.infer<typeof insertApplicationSchema>;
export type Application = typeof applications.$inferSelect;

export type InsertAcademicRecord = z.infer<typeof insertAcademicRecordSchema>;
export type AcademicRecord = typeof academicRecords.$inferSelect;

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;
