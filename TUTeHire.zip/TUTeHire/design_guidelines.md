# Design Guidelines: TUT Student E-Hiring System

## Design Approach
**Selected Framework:** Material Design 3 with professional university customization
**Rationale:** This utility-focused application prioritizes clarity, data density, and efficient task completion. Material Design provides robust patterns for complex dashboards, form-heavy interfaces, and role-based workflows while maintaining accessibility.

## Typography System

**Primary Font:** Inter (Google Fonts)
- Headings: 600 weight for hierarchy
- Body: 400 weight for readability  
- UI Elements: 500 weight for buttons/labels
- Data Tables: 400 weight, slightly condensed

**Scale:**
- Page Titles: text-3xl (30px)
- Section Headers: text-xl (20px)
- Card Titles: text-lg (18px)
- Body Text: text-base (16px)
- Captions/Labels: text-sm (14px)
- Metadata: text-xs (12px)

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16
- Component padding: p-4 to p-6
- Section spacing: gap-6 to gap-8
- Card margins: m-4
- Dashboard gutters: p-8

**Grid Structure:**
- Container max-width: max-w-7xl
- Dashboard sidebar: w-64 (fixed on desktop, collapsible on mobile)
- Main content: flex-1 with appropriate padding
- Job cards grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-3

## Component Library

### Navigation
**Top Navigation Bar:**
- Fixed header with university branding (left)
- User profile dropdown (right)
- Role indicator badge
- Notification bell icon with counter
- Height: h-16

**Sidebar Navigation (Dashboard):**
- Icon + label for each menu item
- Active state with subtle background
- Collapsible on mobile (hamburger menu)
- Group related items with dividers

### Authentication Pages
**Layout:** Centered card on minimal background
- Login/Register form: max-w-md centered
- TUT logo at top
- Clear role selection for new users
- "Remember me" and "Forgot password" links
- Minimal distractions, focus on form

### Job Listings (Student View)
**Card Design:**
- Each job as a card with subtle shadow
- Job title (text-lg, font-semibold)
- Department and position type badges
- Key requirements (bullet points, text-sm)
- Application deadline with icon
- "Apply Now" primary button
- Grid layout with filters sidebar (left)

**Filter Panel:**
- Dropdown for department
- Checkboxes for position type
- Date range picker for deadlines
- "Clear filters" link

### Application Form
**Multi-step Layout:**
- Progress indicator at top (1. Personal Info → 2. Documents → 3. Review)
- Form sections with clear labels
- File upload zones with drag-and-drop
- Resume preview panel
- Validation messages inline
- "Save Draft" secondary button + "Submit" primary button

### Dashboards

**Student Dashboard:**
- Welcome card with student name and status
- "Available Positions" section (3-column grid)
- "My Applications" table with status badges
- Quick stats cards (Applications Submitted, Interviews Scheduled, Offers Received)

**HR/Admin Dashboard:**
- Overview metrics cards (4-column grid): Total Applications, Pending Review, Shortlisted, Positions Open
- Recent activity feed
- AI Ranking insights panel
- Quick actions: "Post New Job", "Export Reports"
- Applicants table with sorting/filtering

**Hiring Manager Dashboard:**
- Job-specific metrics
- Shortlisted candidates table with AI score column
- Interview schedule calendar view
- Candidate comparison tool

### Data Tables
**Structure:**
- Header row with sortable columns
- Alternating row backgrounds for readability
- Action buttons (icon-only) in rightmost column
- Pagination at bottom
- Row hover state
- Status badges with icon indicators
- Checkbox for bulk actions (leftmost column)

### Forms & Inputs
**Consistent Implementation:**
- Labels above inputs (text-sm, font-medium)
- Input height: h-10 to h-12
- Border style: border rounded-md
- Focus states with ring
- Helper text below (text-xs)
- Error states with red accent
- Required field indicator (asterisk)

### Status Badges
**Application States:**
- Submitted: Neutral badge with clock icon
- Under Review: Info badge with eye icon
- Shortlisted: Success badge with star icon
- Interview Scheduled: Warning badge with calendar icon
- Hired: Success badge with check icon
- Rejected: Subtle gray badge with x icon

### Modals & Overlays
**Interview Scheduling Modal:**
- Overlay with backdrop blur
- Centered modal (max-w-2xl)
- Calendar picker for date/time
- Candidate info summary
- Location/meeting link input
- Email notification toggle

**Applicant Details Modal:**
- Full-screen on mobile, large modal on desktop
- Tabs: Profile, Resume, Academic Records, AI Analysis
- Resume viewer with download button
- Academic verification status indicator

### Notifications
**Toast Notifications:**
- Top-right positioned
- Auto-dismiss after 5 seconds
- Icon indicating type (success/info/warning/error)
- Close button

**In-App Notification Center:**
- Dropdown from bell icon
- List of recent notifications
- Unread indicator
- "Mark all as read" action
- Link to full notification history

## Images

**No large hero images** - this is a functional application, not a marketing site.

**Logo/Branding:**
- TUT logo in top navigation (h-10)
- Small institutional badge on login/register pages

**User Avatars:**
- Circular profile images (w-10 h-10) in navigation
- Larger (w-24 h-24) in profile pages
- Placeholder initials for users without photos

**Empty States:**
- Simple illustrations for "No applications yet", "No jobs available"
- Keep minimal and professional

## Responsive Behavior

**Mobile (<768px):**
- Sidebar collapses to hamburger menu
- Single column layouts for cards/grids
- Bottom navigation for key actions
- Tables transform to stacked cards

**Tablet (768px-1024px):**
- 2-column grids
- Sidebar visible but narrower
- Condensed spacing

**Desktop (>1024px):**
- Full 3-column grids
- Expanded sidebar
- Maximum data density
- Hover interactions enabled

## Animations
**Minimal and purposeful:**
- Page transitions: Simple fade (150ms)
- Modal entry: Fade + scale (200ms)
- Dropdown menus: Slide down (150ms)
- No scroll-triggered animations
- Loading spinners for async operations only

## Accessibility
- WCAG AA compliance minimum
- Keyboard navigation for all interactive elements
- ARIA labels for icon buttons
- Focus indicators on all inputs
- Screen reader announcements for status changes
- High contrast mode support