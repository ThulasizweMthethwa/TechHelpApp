import { db } from "./db";
import * as schema from "@shared/schema";
import { eq, and, desc, sql } from "drizzle-orm";
import type { 
  User, InsertUser,
  Job, InsertJob,
  Application, InsertApplication,
  AcademicRecord, InsertAcademicRecord,
  Notification, InsertNotification
} from "@shared/schema";

export interface IStorage {
  // Users
  createUser(user: InsertUser): Promise<User>;
  getUserById(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  
  // Jobs
  createJob(job: InsertJob): Promise<Job>;
  getJobById(id: string): Promise<Job | undefined>;
  getAllJobs(): Promise<Job[]>;
  getOpenJobs(): Promise<Job[]>;
  updateJobStatus(id: string, status: string): Promise<void>;
  
  // Applications
  createApplication(application: InsertApplication): Promise<Application>;
  getApplicationById(id: string): Promise<Application | undefined>;
  getApplicationsByStudent(studentId: string): Promise<Application[]>;
  getApplicationsByJob(jobId: string): Promise<Application[]>;
  updateApplicationStatus(id: string, status: string): Promise<void>;
  updateApplicationAIScore(id: string, score: number): Promise<void>;
  updateApplicationInterview(id: string, date: Date, time: string): Promise<void>;
  
  // Academic Records
  createAcademicRecord(record: InsertAcademicRecord): Promise<AcademicRecord>;
  getAcademicRecordsByStudent(studentId: string): Promise<AcademicRecord[]>;
  
  // Notifications
  createNotification(notification: InsertNotification): Promise<Notification>;
  getNotificationsByUser(userId: string): Promise<Notification[]>;
  markNotificationAsRead(id: string): Promise<void>;
}

export class DbStorage implements IStorage {
  // Users
  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(schema.users).values(insertUser).returning();
    return user;
  }

  async getUserById(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.email, email));
    return user;
  }

  // Jobs
  async createJob(insertJob: InsertJob): Promise<Job> {
    const [job] = await db.insert(schema.jobs).values(insertJob).returning();
    return job;
  }

  async getJobById(id: string): Promise<Job | undefined> {
    const [job] = await db.select().from(schema.jobs).where(eq(schema.jobs.id, id));
    return job;
  }

  async getAllJobs(): Promise<Job[]> {
    return await db.select().from(schema.jobs).orderBy(desc(schema.jobs.postedDate));
  }

  async getOpenJobs(): Promise<Job[]> {
    return await db.select().from(schema.jobs)
      .where(eq(schema.jobs.status, 'open'))
      .orderBy(desc(schema.jobs.postedDate));
  }

  async updateJobStatus(id: string, status: string): Promise<void> {
    await db.update(schema.jobs).set({ status }).where(eq(schema.jobs.id, id));
  }

  // Applications
  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const [application] = await db.insert(schema.applications).values(insertApplication).returning();
    return application;
  }

  async getApplicationById(id: string): Promise<Application | undefined> {
    const [application] = await db.select().from(schema.applications).where(eq(schema.applications.id, id));
    return application;
  }

  async getApplicationsByStudent(studentId: string): Promise<Application[]> {
    return await db.select().from(schema.applications)
      .where(eq(schema.applications.studentId, studentId))
      .orderBy(desc(schema.applications.appliedDate));
  }

  async getApplicationsByJob(jobId: string): Promise<Application[]> {
    return await db.select().from(schema.applications)
      .where(eq(schema.applications.jobId, jobId))
      .orderBy(desc(schema.applications.aiScore));
  }

  async updateApplicationStatus(id: string, status: string): Promise<void> {
    await db.update(schema.applications).set({ status }).where(eq(schema.applications.id, id));
  }

  async updateApplicationAIScore(id: string, score: number): Promise<void> {
    await db.update(schema.applications).set({ aiScore: score }).where(eq(schema.applications.id, id));
  }

  async updateApplicationInterview(id: string, date: Date, time: string): Promise<void> {
    await db.update(schema.applications)
      .set({ interviewDate: date, interviewTime: time, status: 'interview_scheduled' })
      .where(eq(schema.applications.id, id));
  }

  // Academic Records
  async createAcademicRecord(insertRecord: InsertAcademicRecord): Promise<AcademicRecord> {
    const [record] = await db.insert(schema.academicRecords).values(insertRecord).returning();
    return record;
  }

  async getAcademicRecordsByStudent(studentId: string): Promise<AcademicRecord[]> {
    return await db.select().from(schema.academicRecords)
      .where(eq(schema.academicRecords.studentId, studentId))
      .orderBy(desc(schema.academicRecords.year));
  }

  // Notifications
  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const [notification] = await db.insert(schema.notifications).values(insertNotification).returning();
    return notification;
  }

  async getNotificationsByUser(userId: string): Promise<Notification[]> {
    return await db.select().from(schema.notifications)
      .where(eq(schema.notifications.userId, userId))
      .orderBy(desc(schema.notifications.createdAt));
  }

  async markNotificationAsRead(id: string): Promise<void> {
    await db.update(schema.notifications).set({ read: 'true' }).where(eq(schema.notifications.id, id));
  }
}

export const storage = new DbStorage();
