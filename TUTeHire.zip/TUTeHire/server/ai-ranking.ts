import type { AcademicRecord, Job } from "@shared/schema";

// Simple AI ranking algorithm based on academic performance
export function calculateAIScore(academicRecords: AcademicRecord[], job: Job): number {
  if (academicRecords.length === 0) {
    return 50; // Default score if no records
  }

  // Calculate GPA
  const gradeValues: { [key: string]: number } = {
    'A+': 4.0, 'A': 4.0, 'A-': 3.7,
    'B+': 3.3, 'B': 3.0, 'B-': 2.7,
    'C+': 2.3, 'C': 2.0, 'C-': 1.7,
    'D+': 1.3, 'D': 1.0, 'D-': 0.7,
    'F': 0.0
  };

  let totalPoints = 0;
  let totalCredits = 0;

  for (const record of academicRecords) {
    const gradeValue = gradeValues[record.grade] || 0;
    totalPoints += gradeValue * record.credits;
    totalCredits += record.credits;
  }

  const gpa = totalCredits > 0 ? totalPoints / totalCredits : 0;

  // Base score from GPA (0-100 scale)
  let score = (gpa / 4.0) * 70; // GPA contributes up to 70%

  // Check for relevant department match (bonus points)
  const relevantRecords = academicRecords.filter(record => 
    record.courseName.toLowerCase().includes(job.department.toLowerCase().split(' ')[0]) ||
    job.title.toLowerCase().split(' ').some(word => record.courseName.toLowerCase().includes(word))
  );

  if (relevantRecords.length > 0) {
    score += 15; // Relevance bonus
  }

  // Recent academic performance (last 2 years)
  const currentYear = new Date().getFullYear();
  const recentRecords = academicRecords.filter(r => r.year >= currentYear - 2);
  
  if (recentRecords.length > 0) {
    let recentPoints = 0;
    let recentCredits = 0;

    for (const record of recentRecords) {
      const gradeValue = gradeValues[record.grade] || 0;
      recentPoints += gradeValue * record.credits;
      recentCredits += record.credits;
    }

    const recentGPA = recentCredits > 0 ? recentPoints / recentCredits : 0;
    if (recentGPA >= 3.5) {
      score += 15; // Excellent recent performance
    } else if (recentGPA >= 3.0) {
      score += 10; // Good recent performance
    }
  }

  // Ensure score is between 0 and 100
  return Math.min(100, Math.max(0, Math.round(score)));
}

// Mock TUT Student Information System API
export function mockTUTStudentAPI(studentNumber: string): AcademicRecord[] {
  // This simulates fetching academic records from TUT's system
  // In production, this would make an actual API call to TUT's student system
  
  const mockRecords: AcademicRecord[] = [
    {
      id: `rec-${studentNumber}-1`,
      studentId: studentNumber,
      courseCode: "MAT201",
      courseName: "Advanced Mathematics",
      grade: "A",
      credits: 12,
      semester: "1",
      year: 2024,
    },
    {
      id: `rec-${studentNumber}-2`,
      studentId: studentNumber,
      courseCode: "PHY101",
      courseName: "Physics I",
      grade: "B+",
      credits: 12,
      semester: "2",
      year: 2024,
    },
    {
      id: `rec-${studentNumber}-3`,
      studentId: studentNumber,
      courseCode: "CSC202",
      courseName: "Computer Science Fundamentals",
      grade: "A-",
      credits: 12,
      semester: "1",
      year: 2023,
    },
  ];

  return mockRecords;
}
