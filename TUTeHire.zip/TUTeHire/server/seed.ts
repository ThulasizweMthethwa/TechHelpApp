import { storage } from "./storage";
import { hashPassword } from "./auth";

async function seed() {
  console.log("Starting database seed...");

  try {
    // Create users
    const studentPassword = await hashPassword("student123");
    const hrPassword = await hashPassword("hr123");

    const student = await storage.createUser({
      email: "student@tut4life.ac.za",
      password: studentPassword,
      name: "John Doe",
      role: "student",
      studentNumber: "217596190",
    });

    const hrUser = await storage.createUser({
      email: "hr@tut.ac.za",
      password: hrPassword,
      name: "Jane Smith",
      role: "hr",
      studentNumber: null,
    });

    console.log("✓ Created users");

    // Create academic records for student
    await storage.createAcademicRecord({
      studentId: student.id,
      courseCode: "MAT201",
      courseName: "Advanced Mathematics",
      grade: "A",
      credits: 12,
      semester: "1",
      year: 2024,
    });

    await storage.createAcademicRecord({
      studentId: student.id,
      courseCode: "PHY101",
      courseName: "Physics I",
      grade: "B+",
      credits: 12,
      semester: "2",
      year: 2024,
    });

    await storage.createAcademicRecord({
      studentId: student.id,
      courseCode: "CSC202",
      courseName: "Computer Science Fundamentals",
      grade: "A-",
      credits: 12,
      semester: "1",
      year: 2023,
    });

    console.log("✓ Created academic records");

    // Create jobs
    const mathJob = await storage.createJob({
      title: "Mathematics Tutor",
      department: "Faculty of Science",
      positionType: "Tutor",
      description: "Assist students with mathematics courses including calculus, linear algebra, and statistics.",
      requirements: ["Average of 70% or higher in Mathematics", "Completed at least second year", "Strong communication skills"],
      location: "Main Campus",
      hoursPerWeek: 10,
      deadline: new Date("2025-12-31"),
      postedBy: hrUser.id,
    });

    const csJob = await storage.createJob({
      title: "Computer Science Assistant",
      department: "Faculty of ICT",
      positionType: "Student Assistant",
      description: "Help maintain computer labs and assist students with programming assignments.",
      requirements: ["Programming skills in Java/Python", "GPA 3.0 or higher", "Available 10 hours per week"],
      location: "ICT Building",
      hoursPerWeek: 10,
      deadline: new Date("2025-12-25"),
      postedBy: hrUser.id,
    });

    const physicsJob = await storage.createJob({
      title: "Physics Lab Assistant",
      department: "Faculty of Science",
      positionType: "Lab Assistant",
      description: "Prepare lab equipment and assist students during physics laboratory sessions.",
      requirements: ["Strong understanding of physics concepts", "Laboratory safety training", "Attention to detail"],
      location: "Science Block",
      hoursPerWeek: 15,
      deadline: new Date("2025-12-20"),
      postedBy: hrUser.id,
    });

    const englishJob = await storage.createJob({
      title: "English Writing Tutor",
      department: "Faculty of Humanities",
      positionType: "Tutor",
      description: "Provide writing assistance to students for academic papers and essays.",
      requirements: ["Excellent written and verbal English", "Average of 65% or higher", "Patience and empathy"],
      location: "Main Campus",
      hoursPerWeek: 8,
      deadline: new Date("2026-01-15"),
      postedBy: hrUser.id,
    });

    console.log("✓ Created jobs");

    console.log("\nSeed completed successfully!");
    console.log("\nTest credentials:");
    console.log("Student: student@tut4life.ac.za / student123");
    console.log("HR Admin: hr@tut.ac.za / hr123");
    
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}

seed().then(() => process.exit(0)).catch(() => process.exit(1));
