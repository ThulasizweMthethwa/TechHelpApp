import type { Express } from "express";
import { createServer, type Server } from "http";
import express from "express";
import multer from "multer";
import { storage } from "./storage";
import { hashPassword, verifyPassword, generateToken, authMiddleware, roleMiddleware, type AuthRequest } from "./auth";
import { insertUserSchema, insertJobSchema, insertApplicationSchema } from "@shared/schema";
import { calculateAIScore } from "./ai-ranking";

const upload = multer({ 
  dest: 'uploads/',
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  app.use(express.json());

  // =============== AUTH ROUTES ===============
  
  // Register
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ error: "Email already registered" });
      }

      // Hash password and create user
      const hashedPassword = await hashPassword(userData.password);
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      // Generate token
      const token = generateToken(user);

      res.json({
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          studentNumber: user.studentNumber,
        },
        token,
      });
    } catch (error: any) {
      res.status(400).json({ error: error.message || "Registration failed" });
    }
  });

  // Login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({ error: "Email and password required" });
      }

      // Find user
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      // Verify password
      const isValid = await verifyPassword(password, user.password);
      if (!isValid) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      // Generate token
      const token = generateToken(user);

      res.json({
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          studentNumber: user.studentNumber,
        },
        token,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Login failed" });
    }
  });

  // Get current user
  app.get("/api/auth/me", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const user = await storage.getUserById(req.user!.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        studentNumber: user.studentNumber,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // =============== JOB ROUTES ===============
  
  // Get all open jobs (no auth required - public listing)
  app.get("/api/jobs", async (req, res) => {
    try {
      const jobs = await storage.getOpenJobs();
      res.json(jobs);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get job by ID
  app.get("/api/jobs/:id", async (req, res) => {
    try {
      const job = await storage.getJobById(req.params.id);
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }
      res.json(job);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Create job (HR only)
  app.post("/api/jobs", authMiddleware, roleMiddleware('hr', 'hiring_manager'), async (req: AuthRequest, res) => {
    try {
      const jobData = insertJobSchema.parse({
        ...req.body,
        postedBy: req.user!.id,
      });

      const job = await storage.createJob(jobData);
      res.status(201).json(job);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // =============== APPLICATION ROUTES ===============
  
  // Get student's applications
  app.get("/api/applications/my", authMiddleware, roleMiddleware('student'), async (req: AuthRequest, res) => {
    try {
      const applications = await storage.getApplicationsByStudent(req.user!.id);
      
      // Enrich with job details
      const enrichedApplications = await Promise.all(
        applications.map(async (app) => {
          const job = await storage.getJobById(app.jobId);
          return {
            ...app,
            job,
          };
        })
      );

      res.json(enrichedApplications);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get applications for a job (HR only)
  app.get("/api/jobs/:jobId/applications", authMiddleware, roleMiddleware('hr', 'hiring_manager'), async (req, res) => {
    try {
      const applications = await storage.getApplicationsByJob(req.params.jobId);
      
      // Enrich with student details
      const enrichedApplications = await Promise.all(
        applications.map(async (app) => {
          const student = await storage.getUserById(app.studentId);
          return {
            ...app,
            student: student ? {
              id: student.id,
              name: student.name,
              email: student.email,
              studentNumber: student.studentNumber,
            } : null,
          };
        })
      );

      res.json(enrichedApplications);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Submit application
  app.post("/api/applications", authMiddleware, roleMiddleware('student'), upload.single('resume'), async (req: AuthRequest, res) => {
    try {
      const { jobId } = req.body;

      if (!jobId) {
        return res.status(400).json({ error: "Job ID required" });
      }

      // Check if job exists
      const job = await storage.getJobById(jobId);
      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }

      // Create application
      const resumeUrl = req.file ? `/uploads/${req.file.filename}` : null;
      const application = await storage.createApplication({
        jobId,
        studentId: req.user!.id,
        resumeUrl,
      });

      // Calculate AI score asynchronously
      const academicRecords = await storage.getAcademicRecordsByStudent(req.user!.id);
      const aiScore = calculateAIScore(academicRecords, job);
      await storage.updateApplicationAIScore(application.id, aiScore);

      // Create notification
      await storage.createNotification({
        userId: req.user!.id,
        title: "Application Submitted",
        message: `Your application for ${job.title} has been submitted successfully.`,
        type: "success",
      });

      res.status(201).json({ ...application, aiScore });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Update application status (HR only)
  app.patch("/api/applications/:id/status", authMiddleware, roleMiddleware('hr', 'hiring_manager'), async (req, res) => {
    try {
      const { status } = req.body;

      if (!status) {
        return res.status(400).json({ error: "Status required" });
      }

      const application = await storage.getApplicationById(req.params.id);
      if (!application) {
        return res.status(404).json({ error: "Application not found" });
      }

      await storage.updateApplicationStatus(req.params.id, status);

      // Send notification to student
      const job = await storage.getJobById(application.jobId);
      await storage.createNotification({
        userId: application.studentId,
        title: "Application Status Updated",
        message: `Your application for ${job?.title} has been updated to: ${status}`,
        type: "info",
      });

      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Schedule interview (HR only)
  app.post("/api/applications/:id/interview", authMiddleware, roleMiddleware('hr', 'hiring_manager'), async (req, res) => {
    try {
      const { date, time } = req.body;

      if (!date || !time) {
        return res.status(400).json({ error: "Date and time required" });
      }

      const application = await storage.getApplicationById(req.params.id);
      if (!application) {
        return res.status(404).json({ error: "Application not found" });
      }

      await storage.updateApplicationInterview(req.params.id, new Date(date), time);

      // Send notification to student
      const job = await storage.getJobById(application.jobId);
      await storage.createNotification({
        userId: application.studentId,
        title: "Interview Scheduled",
        message: `Your interview for ${job?.title} is scheduled for ${new Date(date).toLocaleDateString()} at ${time}`,
        type: "info",
      });

      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // =============== NOTIFICATION ROUTES ===============
  
  // Get user notifications
  app.get("/api/notifications", authMiddleware, async (req: AuthRequest, res) => {
    try {
      const notifications = await storage.getNotificationsByUser(req.user!.id);
      res.json(notifications);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Mark notification as read
  app.patch("/api/notifications/:id/read", authMiddleware, async (req, res) => {
    try {
      await storage.markNotificationAsRead(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // =============== DASHBOARD STATS ===============
  
  // Student stats
  app.get("/api/stats/student", authMiddleware, roleMiddleware('student'), async (req: AuthRequest, res) => {
    try {
      const applications = await storage.getApplicationsByStudent(req.user!.id);
      
      const stats = {
        totalApplications: applications.length,
        pending: applications.filter(a => a.status === 'submitted' || a.status === 'under_review').length,
        shortlisted: applications.filter(a => a.status === 'shortlisted').length,
        interviewsScheduled: applications.filter(a => a.status === 'interview_scheduled').length,
        offers: applications.filter(a => a.status === 'hired').length,
      };

      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // HR stats
  app.get("/api/stats/hr", authMiddleware, roleMiddleware('hr', 'hiring_manager'), async (req, res) => {
    try {
      const jobs = await storage.getAllJobs();
      const allApplications = await Promise.all(
        jobs.map(job => storage.getApplicationsByJob(job.id))
      );
      const applications = allApplications.flat();

      const stats = {
        totalApplications: applications.length,
        pendingReview: applications.filter(a => a.status === 'submitted' || a.status === 'under_review').length,
        shortlisted: applications.filter(a => a.status === 'shortlisted').length,
        openPositions: jobs.filter(j => j.status === 'open').length,
      };

      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
