import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Briefcase, FileText, Calendar, TrendingUp } from "lucide-react";
import JobCard from "@/components/JobCard";
import StatusBadge from "@/components/StatusBadge";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

export default function StudentDashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats/student"],
  });

  const { data: jobs = [], isLoading: jobsLoading } = useQuery({
    queryKey: ["/api/jobs"],
  });

  const { data: applications = [], isLoading: applicationsLoading } = useQuery({
    queryKey: ["/api/applications/my"],
  });

  const recentJobs = jobs.slice(0, 2);
  const myApplications = applications.slice(0, 3);

  const statsData = stats ? [
    { label: "Applications Submitted", value: stats.totalApplications || 0, icon: FileText, color: "text-primary" },
    { label: "Interviews Scheduled", value: stats.interviewsScheduled || 0, icon: Calendar, color: "text-chart-2" },
    { label: "Offers Received", value: stats.offersReceived || 0, icon: TrendingUp, color: "text-chart-1" },
  ] : [];

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-3xl font-semibold mb-2" data-testid="text-dashboard-title">Welcome Back!</h1>
        <p className="text-muted-foreground">Track your applications and find new opportunities</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {statsLoading ? (
          Array(3).fill(0).map((_, idx) => (
            <Card key={idx}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-4 w-4" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))
        ) : (
          statsData.map((stat, idx) => (
            <Card key={idx} data-testid={`card-stat-${idx}`}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.label}</CardTitle>
                <stat.icon className={`w-4 h-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid={`text-stat-value-${idx}`}>{stat.value}</div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">Available Positions</h2>
          <Button variant="outline" data-testid="button-view-all-jobs">View All</Button>
        </div>
        {jobsLoading ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {Array(2).fill(0).map((_, idx) => (
              <Card key={idx}>
                <CardHeader>
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-1/2 mt-2" />
                </CardHeader>
                <CardContent className="space-y-2">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-10 w-full mt-4" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {recentJobs.map((job) => (
              <JobCard
                key={job.id}
                {...job}
                onApply={(id) => console.log('Apply to job:', id)}
              />
            ))}
          </div>
        )}
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-4">My Applications</h2>
        <Card>
          <CardContent className="p-0">
            {applicationsLoading ? (
              <div className="p-8 space-y-4">
                {Array(3).fill(0).map((_, idx) => (
                  <div key={idx} className="flex items-center justify-between">
                    <div className="space-y-2 flex-1">
                      <Skeleton className="h-5 w-1/3" />
                      <Skeleton className="h-4 w-1/4" />
                    </div>
                    <Skeleton className="h-6 w-24" />
                  </div>
                ))}
              </div>
            ) : myApplications.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">
                No applications yet. Browse available positions to get started!
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="border-b bg-muted/50">
                    <tr>
                      <th className="px-4 py-3 text-left text-sm font-medium">Position</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">Department</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">Applied Date</th>
                      <th className="px-4 py-3 text-right text-sm font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {myApplications.map((app: any) => (
                      <tr key={app.id} className="border-b last:border-0 hover-elevate" data-testid={`row-application-${app.id}`}>
                        <td className="px-4 py-3 text-sm font-medium">{app.job?.title || 'Unknown Position'}</td>
                        <td className="px-4 py-3 text-sm text-muted-foreground">{app.job?.department || 'Unknown'}</td>
                        <td className="px-4 py-3">
                          <StatusBadge status={app.status} />
                        </td>
                        <td className="px-4 py-3 text-sm text-muted-foreground">
                          {new Date(app.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <Button variant="ghost" size="sm" data-testid={`button-view-${app.id}`}>View</Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
