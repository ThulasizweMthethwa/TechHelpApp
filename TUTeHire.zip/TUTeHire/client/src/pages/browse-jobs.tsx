import { useState } from "react";
import JobCard from "@/components/JobCard";
import EmptyState from "@/components/EmptyState";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, SlidersHorizontal } from "lucide-react";
import emptyJobsImage from '@assets/generated_images/Empty_jobs_board_illustration_56c45051.png';
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

export default function BrowseJobs() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDepartment, setSelectedDepartment] = useState("all");
  const [selectedType, setSelectedType] = useState("all");
  const { toast } = useToast();

  const { data: jobs = [], isLoading } = useQuery({
    queryKey: ["/api/jobs"],
  });

  const applyMutation = useMutation({
    mutationFn: async (jobId: number) => {
      await apiRequest("POST", "/api/applications", { jobId });
    },
    onSuccess: () => {
      toast({
        title: "Application submitted",
        description: "Your application has been successfully submitted!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/applications/my"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats/student"] });
    },
    onError: (error: any) => {
      toast({
        title: "Application failed",
        description: error.message || "Failed to submit application. Please try again.",
        variant: "destructive",
      });
    },
  });

  const filteredJobs = jobs.filter((job: any) => {
    const matchesSearch = job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         job.department.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDepartment = selectedDepartment === "all" || job.department === selectedDepartment;
    const matchesType = selectedType === "all" || job.positionType === selectedType;
    return matchesSearch && matchesDepartment && matchesType;
  });

  const handleApply = (jobId: string) => {
    applyMutation.mutate(Number(jobId));
  };

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-3xl font-semibold mb-2" data-testid="text-page-title">Browse Available Positions</h1>
        <p className="text-muted-foreground">Find and apply to student assistant and tutor opportunities</p>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search jobs by title or department..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-jobs"
          />
        </div>
        <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
          <SelectTrigger className="w-full md:w-[200px]" data-testid="select-department">
            <SelectValue placeholder="Department" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Departments</SelectItem>
            <SelectItem value="Faculty of Science">Faculty of Science</SelectItem>
            <SelectItem value="Faculty of ICT">Faculty of ICT</SelectItem>
            <SelectItem value="Faculty of Humanities">Faculty of Humanities</SelectItem>
          </SelectContent>
        </Select>
        <Select value={selectedType} onValueChange={setSelectedType}>
          <SelectTrigger className="w-full md:w-[200px]" data-testid="select-type">
            <SelectValue placeholder="Position Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="Tutor">Tutor</SelectItem>
            <SelectItem value="Student Assistant">Student Assistant</SelectItem>
            <SelectItem value="Lab Assistant">Lab Assistant</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground" data-testid="text-results-count">
          {filteredJobs.length} position{filteredJobs.length !== 1 ? 's' : ''} found
        </p>
        <Button variant="outline" size="sm">
          <SlidersHorizontal className="w-4 h-4 mr-2" />
          More Filters
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
          {Array(6).fill(0).map((_, idx) => (
            <Card key={idx}>
              <CardHeader>
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2 mt-2" />
              </CardHeader>
              <CardContent className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-10 w-full mt-4" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filteredJobs.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredJobs.map((job: any) => (
            <JobCard
              key={job.id}
              {...job}
              onApply={handleApply}
            />
          ))}
        </div>
      ) : (
        <EmptyState
          image={emptyJobsImage}
          title="No jobs found"
          description="Try adjusting your search or filters to find more positions."
          action={<Button variant="outline" onClick={() => {
            setSearchQuery("");
            setSelectedDepartment("all");
            setSelectedType("all");
          }}>Clear Filters</Button>}
        />
      )}
    </div>
  );
}
