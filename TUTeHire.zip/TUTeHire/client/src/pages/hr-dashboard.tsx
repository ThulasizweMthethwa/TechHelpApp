import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, FileText, Calendar, Briefcase, TrendingUp, Clock } from "lucide-react";
import StatusBadge from "@/components/StatusBadge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

export default function HRDashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats/hr"],
  });

  const { data: applications = [], isLoading: applicationsLoading } = useQuery({
    queryKey: ["/api/applications"],
  });

  const recentApplications = applications.slice(0, 4);
  
  const upcomingInterviews = applications
    .filter((app: any) => app.status === "interview_scheduled" && app.interviewDate)
    .slice(0, 3)
    .map((app: any) => ({
      candidate: app.user?.name || 'Unknown',
      position: app.job?.title || 'Unknown',
      date: app.interviewDate,
      time: app.interviewTime || 'TBD'
    }));

  const statsData = stats ? [
    { label: "Total Applications", value: stats.totalApplications || 0, icon: FileText, color: "text-primary", trend: "+12%" },
    { label: "Pending Review", value: stats.pendingReview || 0, icon: Clock, color: "text-chart-3", trend: "+5%" },
    { label: "Shortlisted", value: stats.shortlisted || 0, icon: Users, color: "text-chart-1", trend: "+8%" },
    { label: "Positions Open", value: stats.openPositions || 0, icon: Briefcase, color: "text-chart-2", trend: "-2" },
  ] : [];

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold mb-2" data-testid="text-dashboard-title">HR Dashboard</h1>
          <p className="text-muted-foreground">Overview of recruitment activities and metrics</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" data-testid="button-export-report">
            <TrendingUp className="w-4 h-4 mr-2" />
            Export Report
          </Button>
          <Button data-testid="button-post-job">
            <Briefcase className="w-4 h-4 mr-2" />
            Post New Job
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statsLoading ? (
          Array(4).fill(0).map((_, idx) => (
            <Card key={idx}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-4 w-4" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16" />
              </CardContent>
            </Card>
          ))
        ) : (
          statsData.map((stat, idx) => (
            <Card key={idx} data-testid={`card-stat-${idx}`}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.label}</CardTitle>
                <stat.icon className={`w-4 h-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="flex items-baseline gap-2">
                  <div className="text-2xl font-bold" data-testid={`text-stat-value-${idx}`}>{stat.value}</div>
                  <span className={`text-xs ${stat.trend.startsWith('+') ? 'text-chart-1' : 'text-muted-foreground'}`}>
                    {stat.trend}
                  </span>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Recent Applications</CardTitle>
                <Button variant="ghost" size="sm" data-testid="button-view-all-applications">View All</Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="border-b bg-muted/50">
                    <tr>
                      <th className="px-4 py-3 text-left text-sm font-medium">Candidate</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">Position</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">AI Score</th>
                      <th className="px-4 py-3 text-right text-sm font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {applicationsLoading ? (
                      Array(4).fill(0).map((_, idx) => (
                        <tr key={idx} className="border-b">
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-3">
                              <Skeleton className="h-8 w-8 rounded-full" />
                              <div className="space-y-2">
                                <Skeleton className="h-4 w-32" />
                                <Skeleton className="h-3 w-24" />
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3"><Skeleton className="h-4 w-28" /></td>
                          <td className="px-4 py-3"><Skeleton className="h-6 w-20" /></td>
                          <td className="px-4 py-3"><Skeleton className="h-4 w-16" /></td>
                          <td className="px-4 py-3 text-right"><Skeleton className="h-8 w-16 ml-auto" /></td>
                        </tr>
                      ))
                    ) : recentApplications.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">
                          No recent applications
                        </td>
                      </tr>
                    ) : (
                      recentApplications.map((app: any) => (
                        <tr key={app.id} className="border-b last:border-0 hover-elevate" data-testid={`row-application-${app.id}`}>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-3">
                              <Avatar className="h-8 w-8">
                                <AvatarFallback className="text-xs">{getInitials(app.user?.name || 'Unknown')}</AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium text-sm">{app.user?.name || 'Unknown'}</div>
                                <div className="text-xs text-muted-foreground">{app.job?.department || 'Unknown'}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-sm">{app.job?.title || 'Unknown'}</td>
                          <td className="px-4 py-3">
                            <StatusBadge status={app.status} />
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium">{app.aiScore || 0}%</span>
                              <div className="w-12 h-2 bg-muted rounded-full overflow-hidden">
                                <div className="h-full bg-primary" style={{ width: `${app.aiScore || 0}%` }} />
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-right">
                            <Button variant="ghost" size="sm" data-testid={`button-review-${app.id}`}>Review</Button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Interviews</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {upcomingInterviews.map((interview, idx) => (
                <div key={idx} className="flex items-start gap-3 p-3 rounded-md border hover-elevate" data-testid={`interview-${idx}`}>
                  <Calendar className="w-5 h-5 text-primary mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{interview.candidate}</p>
                    <p className="text-xs text-muted-foreground truncate">{interview.position}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(interview.date).toLocaleDateString()} • {interview.time}
                    </p>
                  </div>
                </div>
              ))}
              <Button variant="outline" className="w-full" size="sm" data-testid="button-view-calendar">
                View Full Calendar
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
