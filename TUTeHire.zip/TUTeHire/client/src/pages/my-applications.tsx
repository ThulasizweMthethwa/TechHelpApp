import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import StatusBadge from "@/components/StatusBadge";
import EmptyState from "@/components/EmptyState";
import { Search, Download, Eye } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import emptyApplicationsImage from '@assets/generated_images/Empty_applications_illustration_8b69edcf.png';
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

export default function MyApplications() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedApp, setSelectedApp] = useState<any>(null);

  const { data: applications = [], isLoading } = useQuery({
    queryKey: ["/api/applications/my"],
  });

  const filteredApplications = applications.filter((app: any) =>
    app.job?.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    app.job?.department.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-3xl font-semibold mb-2" data-testid="text-page-title">My Applications</h1>
        <p className="text-muted-foreground">Track and manage your submitted applications</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search applications..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="input-search-applications"
          />
        </div>
        <Button variant="outline" data-testid="button-export">
          <Download className="w-4 h-4 mr-2" />
          Export
        </Button>
      </div>

      {isLoading ? (
        <Card>
          <CardContent className="p-8">
            <div className="space-y-4">
              {Array(4).fill(0).map((_, idx) => (
                <div key={idx} className="flex items-center justify-between">
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-5 w-1/3" />
                    <Skeleton className="h-4 w-1/4" />
                  </div>
                  <Skeleton className="h-6 w-24" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ) : filteredApplications.length > 0 ? (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b bg-muted/50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-medium">Position</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Department</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Type</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Applied</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">AI Score</th>
                    <th className="px-4 py-3 text-right text-sm font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredApplications.map((app: any) => (
                    <tr key={app.id} className="border-b last:border-0 hover-elevate" data-testid={`row-application-${app.id}`}>
                      <td className="px-4 py-3">
                        <div className="font-medium text-sm">{app.job?.title || 'Unknown Position'}</div>
                        <div className="text-xs text-muted-foreground">Deadline: {app.job?.deadline ? new Date(app.job.deadline).toLocaleDateString() : 'N/A'}</div>
                      </td>
                      <td className="px-4 py-3 text-sm text-muted-foreground">{app.job?.department || 'Unknown'}</td>
                      <td className="px-4 py-3 text-sm text-muted-foreground">{app.job?.positionType || 'Unknown'}</td>
                      <td className="px-4 py-3">
                        <StatusBadge status={app.status} />
                      </td>
                      <td className="px-4 py-3 text-sm text-muted-foreground">
                        {new Date(app.createdAt).toLocaleDateString()}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="text-sm font-medium">{app.aiScore || 0}%</div>
                          <div className="w-12 h-2 bg-muted rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-primary" 
                              style={{ width: `${app.aiScore || 0}%` }}
                            />
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => setSelectedApp(app)}
                              data-testid={`button-view-${app.id}`}
                            >
                              <Eye className="w-4 h-4 mr-1" />
                              View
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl">
                            <DialogHeader>
                              <DialogTitle>{app.job?.title || 'Application Details'}</DialogTitle>
                              <DialogDescription>{app.job?.department || ''}</DialogDescription>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <p className="text-sm font-medium mb-1">Status</p>
                                  <StatusBadge status={app.status} />
                                </div>
                                <div>
                                  <p className="text-sm font-medium mb-1">AI Ranking Score</p>
                                  <p className="text-lg font-semibold">{app.aiScore || 0}%</p>
                                </div>
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <p className="text-sm font-medium mb-1">Applied Date</p>
                                  <p className="text-sm text-muted-foreground">{new Date(app.createdAt).toLocaleDateString()}</p>
                                </div>
                                <div>
                                  <p className="text-sm font-medium mb-1">Application Deadline</p>
                                  <p className="text-sm text-muted-foreground">{app.job?.deadline ? new Date(app.job.deadline).toLocaleDateString() : 'N/A'}</p>
                                </div>
                              </div>
                              {app.status === "interview_scheduled" && app.interviewDate && (
                                <div className="p-4 bg-muted rounded-md">
                                  <p className="text-sm font-medium mb-2">Interview Details</p>
                                  <p className="text-sm text-muted-foreground">
                                    Date: {new Date(app.interviewDate).toLocaleDateString()} at {app.interviewTime || 'TBD'}
                                  </p>
                                  <Button className="mt-3" size="sm">Join Interview</Button>
                                </div>
                              )}
                            </div>
                          </DialogContent>
                        </Dialog>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      ) : (
        <EmptyState
          image={emptyApplicationsImage}
          title="No applications yet"
          description="You haven't submitted any applications. Browse available positions to get started."
          action={<Button>Browse Jobs</Button>}
        />
      )}
    </div>
  );
}
