import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { CalendarIcon, Plus, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function PostJob() {
  const [title, setTitle] = useState("");
  const [department, setDepartment] = useState("");
  const [positionType, setPositionType] = useState("");
  const [description, setDescription] = useState("");
  const [requirements, setRequirements] = useState<string[]>([]);
  const [currentRequirement, setCurrentRequirement] = useState("");
  const [deadline, setDeadline] = useState<Date>();
  const [location, setLocation] = useState("");
  const [hoursPerWeek, setHoursPerWeek] = useState("");
  const { toast } = useToast();
  const [, setLocationPath] = useLocation();

  const postJobMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", "/api/jobs", data);
    },
    onSuccess: () => {
      toast({
        title: "Job posted successfully",
        description: "The job has been posted and is now visible to students.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats/hr"] });
      setLocationPath("/hr/dashboard");
    },
    onError: (error: any) => {
      toast({
        title: "Failed to post job",
        description: error.message || "An error occurred while posting the job.",
        variant: "destructive",
      });
    },
  });

  const handleAddRequirement = () => {
    if (currentRequirement.trim()) {
      setRequirements([...requirements, currentRequirement.trim()]);
      setCurrentRequirement("");
    }
  };

  const handleRemoveRequirement = (index: number) => {
    setRequirements(requirements.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!deadline) {
      toast({
        title: "Missing deadline",
        description: "Please select an application deadline.",
        variant: "destructive",
      });
      return;
    }

    postJobMutation.mutate({
      title,
      department,
      positionType,
      description,
      requirements,
      deadline: deadline.toISOString(),
      location,
      hoursPerWeek: hoursPerWeek ? parseInt(hoursPerWeek) : null,
    });
  };

  return (
    <div className="space-y-6 p-6 max-w-4xl">
      <div>
        <h1 className="text-3xl font-semibold mb-2" data-testid="text-page-title">Post New Job</h1>
        <p className="text-muted-foreground">Create a new position for student assistants or tutors</p>
      </div>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Job Details</CardTitle>
            <CardDescription>Fill in the information about the position</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">Job Title *</Label>
                <Input
                  id="title"
                  placeholder="e.g., Mathematics Tutor"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  data-testid="input-job-title"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="department">Department *</Label>
                <Select value={department} onValueChange={setDepartment} required>
                  <SelectTrigger id="department" data-testid="select-department">
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Faculty of Science">Faculty of Science</SelectItem>
                    <SelectItem value="Faculty of ICT">Faculty of ICT</SelectItem>
                    <SelectItem value="Faculty of Humanities">Faculty of Humanities</SelectItem>
                    <SelectItem value="Faculty of Engineering">Faculty of Engineering</SelectItem>
                    <SelectItem value="Faculty of Management Sciences">Faculty of Management Sciences</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="position-type">Position Type *</Label>
                <Select value={positionType} onValueChange={setPositionType} required>
                  <SelectTrigger id="position-type" data-testid="select-position-type">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Tutor">Tutor</SelectItem>
                    <SelectItem value="Student Assistant">Student Assistant</SelectItem>
                    <SelectItem value="Lab Assistant">Lab Assistant</SelectItem>
                    <SelectItem value="Research Assistant">Research Assistant</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  placeholder="e.g., Main Campus"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  data-testid="input-location"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="hours">Hours per Week</Label>
                <Input
                  id="hours"
                  type="number"
                  placeholder="e.g., 10"
                  value={hoursPerWeek}
                  onChange={(e) => setHoursPerWeek(e.target.value)}
                  data-testid="input-hours"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Job Description *</Label>
              <Textarea
                id="description"
                placeholder="Describe the responsibilities and expectations for this role..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                rows={4}
                data-testid="textarea-description"
              />
            </div>

            <div className="space-y-2">
              <Label>Requirements</Label>
              <div className="flex gap-2">
                <Input
                  placeholder="Add a requirement"
                  value={currentRequirement}
                  onChange={(e) => setCurrentRequirement(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddRequirement())}
                  data-testid="input-requirement"
                />
                <Button
                  type="button"
                  onClick={handleAddRequirement}
                  size="icon"
                  data-testid="button-add-requirement"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              {requirements.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {requirements.map((req, idx) => (
                    <Badge key={idx} variant="secondary" className="gap-1" data-testid={`badge-requirement-${idx}`}>
                      {req}
                      <button
                        type="button"
                        onClick={() => handleRemoveRequirement(idx)}
                        className="ml-1 hover:text-destructive"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label>Application Deadline *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left font-normal"
                    data-testid="button-deadline"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {deadline ? format(deadline, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={deadline}
                    onSelect={setDeadline}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </CardContent>
        </Card>

        <div className="flex gap-3 mt-6">
          <Button type="submit" disabled={postJobMutation.isPending} data-testid="button-publish">
            {postJobMutation.isPending ? "Publishing..." : "Publish Job"}
          </Button>
          <Button type="button" variant="outline" data-testid="button-save-draft">Save as Draft</Button>
          <Button type="button" variant="ghost" onClick={() => setLocationPath("/hr/dashboard")} data-testid="button-cancel">Cancel</Button>
        </div>
      </form>
    </div>
  );
}
