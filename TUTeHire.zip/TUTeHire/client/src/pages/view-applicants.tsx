import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import StatusBadge from "@/components/StatusBadge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Download, FileText, Star } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Label } from "@/components/ui/label";

export default function ViewApplicants() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [selectedPosition, setSelectedPosition] = useState("all");
  const { toast } = useToast();

  const { data: applications = [], isLoading } = useQuery({
    queryKey: ["/api/applications"],
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      await apiRequest("PATCH", `/api/applications/${id}/status`, { status });
    },
    onSuccess: () => {
      toast({
        title: "Status updated",
        description: "Application status has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/applications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats/hr"] });
    },
    onError: (error: any) => {
      toast({
        title: "Update failed",
        description: error.message || "Failed to update status.",
        variant: "destructive",
      });
    },
  });

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const filteredApplicants = applications.filter((app: any) => {
    const name = app.user?.name || '';
    const studentNumber = app.user?.studentNumber || '';
    const matchesSearch = name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         studentNumber.includes(searchQuery);
    const matchesStatus = filterStatus === "all" || app.status === filterStatus;
    const matchesPosition = selectedPosition === "all" || app.job?.title === selectedPosition;
    return matchesSearch && matchesStatus && matchesPosition;
  });

  const topCandidates = [...applications]
    .sort((a: any, b: any) => (b.aiScore || 0) - (a.aiScore || 0))
    .slice(0, 3);

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold mb-2" data-testid="text-page-title">View Applicants</h1>
          <p className="text-muted-foreground">Review and manage candidate applications</p>
        </div>
        <Button variant="outline" data-testid="button-export">
          <Download className="w-4 h-4 mr-2" />
          Export List
        </Button>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all" data-testid="tab-all">All Applicants</TabsTrigger>
          <TabsTrigger value="top" data-testid="tab-top">Top Ranked</TabsTrigger>
        </TabsList>

        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by name or student number..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="input-search"
            />
          </div>
          <Select value={selectedPosition} onValueChange={setSelectedPosition}>
            <SelectTrigger className="w-full md:w-[200px]" data-testid="select-position">
              <SelectValue placeholder="Position" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Positions</SelectItem>
              <SelectItem value="Mathematics Tutor">Mathematics Tutor</SelectItem>
              <SelectItem value="Computer Science Assistant">Computer Science Assistant</SelectItem>
              <SelectItem value="Physics Lab Assistant">Physics Lab Assistant</SelectItem>
              <SelectItem value="English Writing Tutor">English Writing Tutor</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-full md:w-[200px]" data-testid="select-status">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="submitted">Submitted</SelectItem>
              <SelectItem value="under_review">Under Review</SelectItem>
              <SelectItem value="shortlisted">Shortlisted</SelectItem>
              <SelectItem value="interview_scheduled">Interview Scheduled</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="border-b bg-muted/50">
                    <tr>
                      <th className="px-4 py-3 text-left text-sm font-medium">Candidate</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">Position</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">AI Score</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">GPA</th>
                      <th className="px-4 py-3 text-left text-sm font-medium">Applied</th>
                      <th className="px-4 py-3 text-right text-sm font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {isLoading ? (
                      Array(5).fill(0).map((_, idx) => (
                        <tr key={idx} className="border-b">
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-3">
                              <Skeleton className="h-8 w-8 rounded-full" />
                              <div className="space-y-2">
                                <Skeleton className="h-4 w-32" />
                                <Skeleton className="h-3 w-24" />
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3"><Skeleton className="h-4 w-28" /></td>
                          <td className="px-4 py-3"><Skeleton className="h-6 w-20" /></td>
                          <td className="px-4 py-3"><Skeleton className="h-4 w-16" /></td>
                          <td className="px-4 py-3"><Skeleton className="h-4 w-12" /></td>
                          <td className="px-4 py-3"><Skeleton className="h-4 w-20" /></td>
                          <td className="px-4 py-3 text-right"><Skeleton className="h-8 w-16 ml-auto" /></td>
                        </tr>
                      ))
                    ) : filteredApplicants.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="px-4 py-8 text-center text-muted-foreground">
                          No applicants found
                        </td>
                      </tr>
                    ) : (
                      filteredApplicants.map((app: any) => (
                        <tr key={app.id} className="border-b last:border-0 hover-elevate" data-testid={`row-applicant-${app.id}`}>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-3">
                              <Avatar className="h-8 w-8">
                                <AvatarFallback className="text-xs">{getInitials(app.user?.name || 'Unknown')}</AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium text-sm">{app.user?.name || 'Unknown'}</div>
                                <div className="text-xs text-muted-foreground">{app.user?.studentNumber || 'N/A'}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <div className="text-sm">{app.job?.title || 'Unknown'}</div>
                            <div className="text-xs text-muted-foreground">{app.job?.department || 'Unknown'}</div>
                          </td>
                          <td className="px-4 py-3">
                            <Select 
                              value={app.status} 
                              onValueChange={(value) => updateStatusMutation.mutate({ id: app.id, status: value })}
                              disabled={updateStatusMutation.isPending}
                            >
                              <SelectTrigger className="w-[180px]">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="submitted">Submitted</SelectItem>
                                <SelectItem value="under_review">Under Review</SelectItem>
                                <SelectItem value="shortlisted">Shortlisted</SelectItem>
                                <SelectItem value="interview_scheduled">Interview Scheduled</SelectItem>
                                <SelectItem value="accepted">Accepted</SelectItem>
                                <SelectItem value="rejected">Rejected</SelectItem>
                              </SelectContent>
                            </Select>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium">{app.aiScore || 0}%</span>
                              <div className="w-12 h-2 bg-muted rounded-full overflow-hidden">
                                <div className="h-full bg-primary" style={{ width: `${app.aiScore || 0}%` }} />
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-sm font-medium">{app.user?.gpa || 'N/A'}</td>
                          <td className="px-4 py-3 text-sm text-muted-foreground">
                            {new Date(app.createdAt).toLocaleDateString()}
                          </td>
                          <td className="px-4 py-3 text-right">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="ghost" size="sm" data-testid={`button-view-${app.id}`}>
                                  <FileText className="w-4 h-4 mr-1" />
                                  View
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-2xl">
                                <DialogHeader>
                                  <DialogTitle>{app.user?.name || 'Unknown'}</DialogTitle>
                                  <DialogDescription>{app.user?.studentNumber || 'N/A'} • {app.user?.email || 'N/A'}</DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <div className="grid grid-cols-2 gap-4">
                                    <div>
                                      <p className="text-sm font-medium mb-1">Position Applied</p>
                                      <p className="text-sm text-muted-foreground">{app.job?.title || 'Unknown'}</p>
                                    </div>
                                    <div>
                                      <p className="text-sm font-medium mb-1">Department</p>
                                      <p className="text-sm text-muted-foreground">{app.job?.department || 'Unknown'}</p>
                                    </div>
                                  </div>
                                  <div className="grid grid-cols-3 gap-4">
                                    <div>
                                      <p className="text-sm font-medium mb-1">AI Score</p>
                                      <p className="text-lg font-semibold">{app.aiScore || 0}%</p>
                                    </div>
                                    <div>
                                      <p className="text-sm font-medium mb-1">GPA</p>
                                      <p className="text-lg font-semibold">{app.user?.gpa || 'N/A'}</p>
                                    </div>
                                    <div>
                                      <p className="text-sm font-medium mb-1">Status</p>
                                      <StatusBadge status={app.status} />
                                    </div>
                                  </div>
                                  <div>
                                    <p className="text-sm font-medium mb-2">Cover Letter</p>
                                    <p className="text-sm text-muted-foreground">{app.coverLetter || 'No cover letter provided'}</p>
                                  </div>
                                  <div className="flex gap-2 pt-4">
                                    <Button 
                                      size="sm" 
                                      onClick={() => updateStatusMutation.mutate({ id: app.id, status: 'shortlisted' })}
                                      disabled={updateStatusMutation.isPending}
                                    >
                                      Shortlist
                                    </Button>
                                    <Button 
                                      size="sm" 
                                      variant="outline"
                                      onClick={() => updateStatusMutation.mutate({ id: app.id, status: 'interview_scheduled' })}
                                      disabled={updateStatusMutation.isPending}
                                    >
                                      Schedule Interview
                                    </Button>
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="top" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="w-5 h-5 text-primary" />
                Top 3 AI-Ranked Candidates
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {topCandidates.map((candidate, idx) => (
                <div key={candidate.id} className="p-4 border rounded-md space-y-3 hover-elevate" data-testid={`top-candidate-${idx}`}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground font-semibold text-sm">
                        {idx + 1}
                      </div>
                      <Avatar className="h-10 w-10">
                        <AvatarFallback>{getInitials(candidate.name)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{candidate.name}</p>
                        <p className="text-sm text-muted-foreground">{candidate.studentNumber}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-primary">{candidate.aiScore}%</p>
                      <p className="text-xs text-muted-foreground">AI Score</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Position</p>
                      <p className="font-medium">{candidate.position}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">GPA</p>
                      <p className="font-medium">{candidate.gpa}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Status</p>
                      <StatusBadge status={candidate.status} />
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {candidate.skills.map((skill, skillIdx) => (
                      <Badge key={skillIdx} variant="outline" className="text-xs">{skill}</Badge>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline">View Profile</Button>
                    <Button size="sm">Schedule Interview</Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
