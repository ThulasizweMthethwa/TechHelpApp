import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import Header from "@/components/Header";
import NotFound from "@/pages/not-found";
import LoginPage from "@/pages/login";
import StudentDashboard from "@/pages/student-dashboard";
import BrowseJobs from "@/pages/browse-jobs";
import MyApplications from "@/pages/my-applications";
import HRDashboard from "@/pages/hr-dashboard";
import PostJob from "@/pages/post-job";
import ViewApplicants from "@/pages/view-applicants";
import { AuthProvider, useAuth } from "@/lib/auth-context";

function AuthenticatedApp() {
  const [location] = useLocation();
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]" />
          <p className="mt-4 text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginPage />;
  }

  const userRole = user.role === "student" ? "student" : "hr";

  const sidebarStyle = {
    "--sidebar-width": "16rem",
  };

  return (
    <SidebarProvider style={sidebarStyle as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar role={userRole} currentPath={location} />
        <div className="flex flex-col flex-1 overflow-hidden">
          <Header userName={user.name} userRole={userRole} notificationCount={3} />
          <main className="flex-1 overflow-auto">
            <Switch>
              {/* Student Routes */}
              <Route path="/student/dashboard" component={StudentDashboard} />
              <Route path="/student/jobs" component={BrowseJobs} />
              <Route path="/student/applications" component={MyApplications} />
              
              {/* HR Routes */}
              <Route path="/hr/dashboard" component={HRDashboard} />
              <Route path="/hr/post-job" component={PostJob} />
              <Route path="/hr/applicants" component={ViewApplicants} />
              
              {/* Default Routes */}
              <Route path="/">
                {userRole === "student" ? <StudentDashboard /> : <HRDashboard />}
              </Route>
              <Route component={NotFound} />
            </Switch>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <AuthenticatedApp />
        </AuthProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
