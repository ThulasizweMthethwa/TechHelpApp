import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";
import { Home, Briefcase, FileText, Calendar, PlusCircle, Users, BarChart } from "lucide-react";

interface AppSidebarProps {
  role: "student" | "hr" | "hiring_manager";
  currentPath?: string;
}

export function AppSidebar({ role, currentPath = "/" }: AppSidebarProps) {
  const studentItems = [
    { title: "Dashboard", url: "/student/dashboard", icon: Home },
    { title: "Browse Jobs", url: "/student/jobs", icon: Briefcase },
    { title: "My Applications", url: "/student/applications", icon: FileText },
  ];

  const hrItems = [
    { title: "Dashboard", url: "/hr/dashboard", icon: Home },
    { title: "Post Job", url: "/hr/post-job", icon: PlusCircle },
    { title: "View Applicants", url: "/hr/applicants", icon: Users },
    { title: "Interviews", url: "/hr/interviews", icon: Calendar },
    { title: "Reports", url: "/hr/reports", icon: BarChart },
  ];

  const items = role === "student" ? studentItems : hrItems;

  return (
    <Sidebar data-testid="sidebar-main">
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>
            {role === "student" ? "Student Portal" : "HR Admin Portal"}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton 
                    asChild
                    isActive={currentPath === item.url}
                    data-testid={`link-${item.title.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <a href={item.url}>
                      <item.icon />
                      <span>{item.title}</span>
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
