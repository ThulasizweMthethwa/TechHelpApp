import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, MapPin, Briefcase } from "lucide-react";

interface JobCardProps {
  id: string;
  title: string;
  department: string;
  positionType: string;
  requirements: string[];
  deadline: string;
  postedDate: string;
  location?: string;
  onApply?: (id: string) => void;
}

export default function JobCard({ 
  id, 
  title, 
  department, 
  positionType, 
  requirements, 
  deadline, 
  postedDate,
  location = "On Campus",
  onApply 
}: JobCardProps) {
  return (
    <Card className="hover-elevate" data-testid={`card-job-${id}`}>
      <CardHeader className="space-y-0 pb-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <CardTitle className="text-lg">{title}</CardTitle>
          <Badge variant="secondary" data-testid={`badge-position-type-${id}`}>{positionType}</Badge>
        </div>
        <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
          <span className="flex items-center gap-1">
            <Briefcase className="w-3 h-3" />
            {department}
          </span>
          <span className="flex items-center gap-1">
            <MapPin className="w-3 h-3" />
            {location}
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <p className="text-sm font-medium">Requirements:</p>
          <ul className="text-sm text-muted-foreground space-y-1">
            {requirements.slice(0, 3).map((req, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-primary mt-1">•</span>
                <span>{req}</span>
              </li>
            ))}
          </ul>
        </div>
      </CardContent>
      <CardFooter className="flex flex-wrap items-center justify-between gap-2 pt-4 border-t">
        <div className="flex flex-col gap-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            Deadline: {new Date(deadline).toLocaleDateString()}
          </span>
          <span className="flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            Posted: {new Date(postedDate).toLocaleDateString()}
          </span>
        </div>
        <Button 
          onClick={() => onApply?.(id)} 
          data-testid={`button-apply-${id}`}
        >
          Apply Now
        </Button>
      </CardFooter>
    </Card>
  );
}
