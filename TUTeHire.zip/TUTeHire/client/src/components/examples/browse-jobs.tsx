import BrowseJobs from '../../pages/browse-jobs';

export default function BrowseJobsExample() {
  return <BrowseJobs />;
}
