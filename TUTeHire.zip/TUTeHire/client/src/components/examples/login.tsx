import LoginPage from '../../pages/login';

export default function LoginPageExample() {
  return <LoginPage />;
}
