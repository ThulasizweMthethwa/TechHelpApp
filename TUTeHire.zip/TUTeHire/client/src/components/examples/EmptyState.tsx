import EmptyState from '../EmptyState';
import { Button } from '@/components/ui/button';
import emptyJobsImage from '@assets/generated_images/Empty_jobs_board_illustration_56c45051.png';

export default function EmptyStateExample() {
  return (
    <EmptyState
      image={emptyJobsImage}
      title="No jobs available"
      description="There are currently no open positions. Check back later for new opportunities."
      action={<Button variant="outline">Refresh</Button>}
    />
  );
}
