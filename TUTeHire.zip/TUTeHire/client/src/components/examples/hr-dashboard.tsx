import HRDashboard from '../../pages/hr-dashboard';

export default function HRDashboardExample() {
  return <HRDashboard />;
}
