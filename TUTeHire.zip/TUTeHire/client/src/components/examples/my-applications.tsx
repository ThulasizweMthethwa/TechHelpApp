import MyApplications from '../../pages/my-applications';

export default function MyApplicationsExample() {
  return <MyApplications />;
}
