import StudentDashboard from '../../pages/student-dashboard';

export default function StudentDashboardExample() {
  return <StudentDashboard />;
}
