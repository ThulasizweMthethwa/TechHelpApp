import ViewApplicants from '../../pages/view-applicants';

export default function ViewApplicantsExample() {
  return <ViewApplicants />;
}
