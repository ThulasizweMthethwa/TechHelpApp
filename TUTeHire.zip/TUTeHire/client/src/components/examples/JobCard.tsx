import JobCard from '../JobCard';

export default function JobCardExample() {
  return (
    <div className="max-w-md">
      <JobCard
        id="1"
        title="Mathematics Tutor"
        department="Faculty of Science"
        positionType="Tutor"
        requirements={[
          "Average of 70% or higher in Mathematics",
          "Completed at least second year",
          "Strong communication skills"
        ]}
        deadline="2025-12-31"
        postedDate="2025-11-01"
        onApply={(id) => console.log('Apply clicked for job:', id)}
      />
    </div>
  );
}
