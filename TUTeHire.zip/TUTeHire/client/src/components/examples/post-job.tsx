import PostJob from '../../pages/post-job';

export default function PostJobExample() {
  return <PostJob />;
}
