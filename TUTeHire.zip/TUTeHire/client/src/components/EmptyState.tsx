interface EmptyStateProps {
  image: string;
  title: string;
  description: string;
  action?: React.ReactNode;
}

export default function EmptyState({ image, title, description, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-4 text-center" data-testid="empty-state">
      <img src={image} alt={title} className="w-32 h-32 mb-6 opacity-50" />
      <h3 className="text-lg font-semibold text-foreground mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground mb-6 max-w-md">{description}</p>
      {action}
    </div>
  );
}
