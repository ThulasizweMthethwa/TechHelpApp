import { Badge } from "@/components/ui/badge";
import { Clock, Eye, Star, Calendar, CheckCircle, XCircle } from "lucide-react";

type ApplicationStatus = 
  | "submitted" 
  | "under_review" 
  | "shortlisted" 
  | "interview_scheduled" 
  | "hired" 
  | "rejected";

interface StatusBadgeProps {
  status: ApplicationStatus;
  className?: string;
}

const statusConfig = {
  submitted: {
    label: "Submitted",
    variant: "secondary" as const,
    icon: Clock,
  },
  under_review: {
    label: "Under Review",
    variant: "default" as const,
    icon: Eye,
  },
  shortlisted: {
    label: "Shortlisted",
    variant: "default" as const,
    icon: Star,
  },
  interview_scheduled: {
    label: "Interview Scheduled",
    variant: "secondary" as const,
    icon: Calendar,
  },
  hired: {
    label: "Hired",
    variant: "default" as const,
    icon: CheckCircle,
  },
  rejected: {
    label: "Rejected",
    variant: "outline" as const,
    icon: XCircle,
  },
};

export default function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <Badge variant={config.variant} className={className} data-testid={`badge-status-${status}`}>
      <Icon className="w-3 h-3 mr-1" />
      {config.label}
    </Badge>
  );
}
